<?php 
namespace Lof\RewardPoints\Observer;
use Magento\Customer\Api\CustomerRepositoryInterface;

class OrderPlaceAfter implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $customerRepository;


    /**
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        CustomerRepositoryInterface $customerRepository
    ){
        $this->customerRepository = $customerRepository;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     *
     * @return void
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function execute(\Magento\Framework\Event\Observer $observer){
        $order = $observer->getEvent()->getOrder(); 
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/logfile.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info($customer = $order->getCustomerId());

        $customer_id = $order->getCustomerId();
        $customer = $this->customerRepository->getById($customer_id);
        $reward_points = $customer->getCustomAttribute("reward_points")->getValue() ?: 0;
        if($reward_points > 0) {
            $reward_points = $reward_points - 1;
            $customer->setCustomAttribute("reward_points",$reward_points);
            $this->customerRepository->save($customer);
        }
        $orderTotal = $order->getSubtotal();

        if ($orderTotal >= 100) {
            $reward_points = $reward_points + 1;
            $customer->setCustomAttribute("reward_points",$reward_points);
            $this->customerRepository->save($customer);
        }
        
        
        
    } 
}
 