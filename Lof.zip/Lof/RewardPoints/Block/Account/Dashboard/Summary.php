<?php
namespace Lof\RewardPoints\Block\Account\Dashboard;

class Summary extends \Magento\Framework\View\Element\Template
{
  
    public function __construct(
    	\Magento\Catalog\Block\Product\Context $context,
        \Lof\RewardPoints\Helper\Customer $rewardsCustomer,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Customer\Model\Customer $customer,
        array $data = []
    ) {
    	parent::__construct($context);
        $this->rewardsCustomer  = $rewardsCustomer;
        $this->customerSession = $customerSession;
        $this->customer = $customer;
    }

    /**
     * Get current reward customer
     * @return \Lof\RewardPoints\Model\Customer
     */
    public function getCustomerRewardPoints()
    {
        $customerId = $this->customerSession->getCustomer()->getId();
        $customer   = $this->customer->load($customerId);
        $reward_points = $this->customer->getData('reward_points') ?: 0;
        return $reward_points;
    }

    
}