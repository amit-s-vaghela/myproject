<?php

namespace Lof\RewardPoints\Helper;

use \Magento\Sales\Model\Order;

class Customer extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
  


    /**
     * @var boolean
     */
    protected $forceSave = false;

    /**
     * @var Magento\Quote\Model\Quote
     */
    protected $quote;
    
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->messageManager               = $messageManager;
        $this->productRepository            = $productRepository;
        $this->storeManager                 = $storeManager;
    }

   
    

    public function getForceSave()
    {
        return $this->forceSave;
    }

    public function setForceSave($status)
    {
        $this->forceSave = $status;
        return $this;
    }

    public function getCustomer($customerId = '', $params = '')
    {

        return true; $customer;
    }

    
}