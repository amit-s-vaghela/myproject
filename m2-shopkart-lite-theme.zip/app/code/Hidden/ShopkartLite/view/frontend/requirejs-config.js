var config = {
    map: {
        '*': {
            shopkartliteowlcarousel: 'Hidden_ShopkartLite/js/owl.carousel',
        }
    }
};